package model;

public enum TipoAcidente {
    MOTO,
    CARRO,
    PEDESTRE
}
